﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.Http.Routing;

namespace WebApiRouteDemo
{
    public class ClassifiedHttpControllerSelector : DefaultHttpControllerSelector
    {
        private const string AREA_ROUTE_VARIABLE_NAME = "area";
        private const string CATEGORY_ROUTE_VARIABLE_NAME = "category";

        private const string THE_FIX_CONTROLLER_FOLDER_NAME = "Controllers";

        private readonly HttpConfiguration m_configuration;
        private readonly Lazy<ConcurrentDictionary<string, Type>> m_apiControllerTypes;

        public ClassifiedHttpControllerSelector(HttpConfiguration configuration) : base(configuration)
        {
            m_configuration = configuration;
            m_apiControllerTypes = new Lazy<ConcurrentDictionary<string, Type>>(GetAllControllerTypes);
        }

        public override HttpControllerDescriptor SelectController(HttpRequestMessage request)
        {
            return GetApiController(request);
        }

        private static string GetRouteValueByName(HttpRequestMessage request, string strRouteName)
        {
            IHttpRouteData data = request.GetRouteData();
            if (data.Values.ContainsKey(strRouteName))
            {
                return data.Values[strRouteName] as string;
            }
            return null;
        }

        private static ConcurrentDictionary<string, Type> GetAllControllerTypes()
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            Dictionary<string, Type> types = assemblies.SelectMany(a => a.GetTypes().Where(t => !t.IsAbstract && t.Name.EndsWith(ControllerSuffix, StringComparison.OrdinalIgnoreCase) && typeof(IHttpController).IsAssignableFrom(t))).ToDictionary(t => t.FullName, t => t);
            return new ConcurrentDictionary<string, Type>(types);
        }

        private HttpControllerDescriptor GetApiController(HttpRequestMessage request)
        {
            string strAreaName = GetRouteValueByName(request, AREA_ROUTE_VARIABLE_NAME);
            string strCategoryName = GetRouteValueByName(request, CATEGORY_ROUTE_VARIABLE_NAME);
            string strControllerName = GetControllerName(request);
            Type type;
            try
            {
                type = GetControllerType(strAreaName, strCategoryName, strControllerName);
            }
            catch (Exception)
            {
                return null;
            }
            return new HttpControllerDescriptor(m_configuration, strControllerName, type);
        }

        private Type GetControllerType(string areaName, string categoryName, string controllerName)
        {
            IEnumerable<KeyValuePair<string, Type>> query = m_apiControllerTypes.Value.AsEnumerable();
            string strControllerSearchingName;
            if (string.IsNullOrEmpty(areaName))
            {
                strControllerSearchingName = THE_FIX_CONTROLLER_FOLDER_NAME + "." + controllerName;
            }
            else
            {
                if (string.IsNullOrEmpty(categoryName))
                {
                    strControllerSearchingName = THE_FIX_CONTROLLER_FOLDER_NAME + "." + areaName + "." + controllerName;
                }
                else
                {
                    strControllerSearchingName = THE_FIX_CONTROLLER_FOLDER_NAME + "." + areaName + "." + categoryName + "." + controllerName;
                }
            }
            return query.Where(x => x.Key.IndexOf(strControllerSearchingName, StringComparison.OrdinalIgnoreCase) != -1).Select(x => x.Value).Single();
        }
    }
}