﻿using System.Collections.Generic;
using System.Web.Http;

namespace WebApiRouteDemo.Controllers.Products.Enterprise
{
    public class FinancialController : ApiController
    {
        // GET api/financial
        public IEnumerable<string> Get()
        {
            return new[] {"value1", "value2"};
        }

        // GET api/financial/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/financial
        public void Post([FromBody] string value)
        {
        }

        // PUT api/financial/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/financial/5
        public void Delete(int id)
        {
        }
    }
}