﻿using System.Collections.Generic;
using System.Web.Http;

namespace WebApiRouteDemo.Controllers.Products.Game
{
    public class PuzController : ApiController
    {
        // GET api/puz
        public IEnumerable<string> Get()
        {
            return new[] {"value1", "value2"};
        }

        // GET api/puz/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/puz
        public void Post([FromBody] string value)
        {
        }

        // PUT api/puz/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/puz/5
        public void Delete(int id)
        {
        }
    }
}